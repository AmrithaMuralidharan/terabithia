// script.js
window.onload = () => {
    const canvas = document.getElementById('exosky');
    const ctx = canvas.getContext('2d');
    const planetDropdown = document.getElementById('planetDropdown');
    let drawing = false;
    let stars = [];

    // Example: Predefined star positions for different exoplanets
    const exoplanetStars = {
        planet1: [
            { x: 100, y: 150 },
            { x: 300, y: 80 },
            { x: 400, y: 200 },
            { x: 600, y: 120 }
        ],
        planet2: [
            { x: 120, y: 180 },
            { x: 350, y: 100 },
            { x: 450, y: 250 },
            { x: 700, y: 130 }
        ],
        planet3: [
            { x: 50, y: 200 },
            { x: 250, y: 90 },
            { x: 500, y: 220 },
            { x: 700, y: 150 }
        ]
    };

    // Draw Stars Function
    function drawStars(starsArray) {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        starsArray.forEach(star => {
            ctx.beginPath();
            ctx.arc(star.x, star.y, 5, 0, Math.PI * 2);
            ctx.fillStyle = '#ffffff';
            ctx.fill();
            ctx.closePath();
        });
    }

    // Load selected planet stars
    planetDropdown.addEventListener('change', () => {
        const planet = planetDropdown.value;
        if (exoplanetStars[planet]) {
            stars = exoplanetStars[planet];
            drawStars(stars);
        } else {
            ctx.clearRect(0, 0, canvas.width, canvas.height);  // Clear canvas if no planet selected
        }
    });

    // Drawing constellations (Connecting stars)
    const drawConstellationButton = document.getElementById('drawConstellation');
    drawConstellationButton.addEventListener('click', () => {
        if (stars.length > 1) {
            ctx.beginPath();
            ctx.moveTo(stars[0].x, stars[0].y);
            for (let i = 1; i < stars.length; i++) {
                ctx.lineTo(stars[i].x, stars[i].y);
            }
            ctx.strokeStyle = '#ffcc00';
            ctx.stroke();
            ctx.closePath();
        }
    });

    // Clear constellations
    const clearButton = document.getElementById('clearConstellation');
    clearButton.addEventListener('click', () => {
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        drawStars(stars);  // Redraw stars after clearing
    });
};
