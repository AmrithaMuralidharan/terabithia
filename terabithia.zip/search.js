function showExoplanetInfo() {
    var exoplanetInfo = {
        "Proxima Centauri b": "Orbiting Proxima Centauri, ~4.2 light years from Earth. A potentially habitable terrestrial planet.",
        "TRAPPIST-1e": "One of the seven Earth-sized planets orbiting TRAPPIST-1, ~39 light years away, possibly habitable.",
        "Kepler-452b": "Orbiting Kepler-452, ~1,400 light years from Earth. It is considered a Super-Earth in the habitable zone.",
        "HD 209458 b (Osiris)": "A hot Jupiter orbiting HD 209458, ~157 light years from Earth. It is a gas giant.",
        "55 Cancri e": "A Super-Earth orbiting 55 Cancri, ~41 light years from Earth. This planet is extremely hot.",
        "WASP-12b": "A hot Jupiter orbiting WASP-12, ~1,400 light years away. This planet is very close to its star.",
        "Gliese 581d": "A Super-Earth orbiting Gliese 581, ~20 light years away. It is in the habitable zone.",
        "LHS 1140 b": "A Super-Earth orbiting LHS 1140, ~40 light years away. It is potentially habitable.",
        "Kepler-22b": "A Super-Earth orbiting Kepler-22, ~600 light years from Earth, located in the habitable zone.",
        "TOI 700 d": "An Earth-sized exoplanet orbiting TOI 700, ~100 light years away, within the habitable zone."
    };

    var selectedExoplanet = document.getElementById("exoplanetDropdown").value;
    var infoBox = document.getElementById("exoplanetInfo");

    if (selectedExoplanet) {
        infoBox.innerHTML = "<strong>" + selectedExoplanet + ":</strong> " + exoplanetInfo[selectedExoplanet];
    } else {
        infoBox.innerHTML = "";
    }
}
