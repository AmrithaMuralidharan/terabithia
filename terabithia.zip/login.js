// Placeholder for future interactivity, such as animations or VR mode
document.addEventListener('DOMContentLoaded', function () {
    console.log("Welcome to Terabithia!");
});
